---
enable: true
title: "What Users Are Saying About Hugoplate"
description: "Don't just take our word for it - hear from some of our satisfied users!  Check out some of our testimonials below to see what others are saying about Hugoplate."

# Testimonials
testimonials:
  - name: "Marvin McKinney"
    designation: "Web Designer"
    avatar: "/images/avatar-sm.png"
    content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui iusto illo molestias, assumenda expedita commodi inventore non itaque molestiae voluptatum dolore, facilis sapiente, repellat veniam."

  - name: "Marvin McKinney"
    designation: "Web Designer"
    avatar: "/images/avatar-sm.png"
    content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui iusto illo molestias, assumenda expedita commodi inventore non itaque molestiae voluptatum dolore, facilis sapiente, repellat veniam."

  - name: "Marvin McKinney"
    designation: "Web Designer"
    avatar: "/images/avatar-sm.png"
    content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui iusto illo molestias, assumenda expedita commodi inventore non itaque molestiae voluptatum dolore, facilis sapiente, repellat veniam."

  - name: "Marvin McKinney"
    designation: "Web Designer"
    avatar: "/images/avatar-sm.png"
    content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui iusto illo molestias, assumenda expedita commodi inventore non itaque molestiae voluptatum dolore, facilis sapiente, repellat veniam."

# don't create a separate page
_build:
  render: "never"
---
